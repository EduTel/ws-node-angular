# inicio
ejecutar el comando npm install para descargar las dependencias
versiones de angular
https://github.com/angular/code.angularjs.org
